#!/bin/sh 
# run_wifi_first.sh

# echo 0 >/sys/class/gpio/gpio12/value # 0

date -s "2026-06-29 00:00:00"

bspmm 0x10260028 0x1130
mount -t vfat /dev/mmcblk0p1 /mnt

cd /opt/ko/load3516cv610/
./load3516cv610_20s_debug -i -mmz_start 0x44000000 -mmz_size 64M
sleep 0.5

echo 12 >/sys/class/gpio/export
echo out >/sys/class/gpio/gpio12/direction
echo 0 >/sys/class/gpio/gpio12/value # 0
# echo 12 >/sys/class/gpio/unexport

echo host >/proc/wing-usb/10300000.usb20drd/mode
sleep 0.5

cd /home/wifi_file/ko
# insmod firmware_class.ko
# insmod cfg80211.ko
insmod mac80211.ko
insmod plat_soc.ko 
insmod wifi_soc.ko
sleep 0.5

cd /home
./get_mac.sh

ifconfig wlan0 192.168.10.2 up

rm -f /var/run/hostapd/wlan0
hostapd /etc/Wireless/hostapd.conf &

busybox udhcpd -S /etc/Wireless/udhcpd.conf &
sleep 1

bspmm 0x10260028 0x1130
mount -t vfat /dev/mmcblk0p1 /mnt

cd /home
./ceanic_app &

sleep 0.5
exit 0
