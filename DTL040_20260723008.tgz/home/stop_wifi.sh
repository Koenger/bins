#!/bin/sh
# stop_wifi.sh

# GPIO12 指示灯
echo 12 >/sys/class/gpio/export
echo out >/sys/class/gpio/gpio12/direction
echo 1 >/sys/class/gpio/gpio12/value
echo 12 >/sys/class/gpio/unexport

# 退出程序
killall -2 ceanic_app 2>/dev/null

# 等待进程真正结束，循环检测 20 次 (2秒)
count=0
while [ $count -lt 50 ]; do
    if ! pgrep ceanic_app > /dev/null; then
        echo "App stopped gracefully."
        # ★★★ 关键：无论程序是否正常释放，强制重置 MPP 系统，清空 VB 和 MMZ ★★★
        if [ -f /proc/umap/sys ]; then
            echo 0 > /proc/umap/sys 2>/dev/null
            echo "MPP system force reset successfully."
        fi
        break
    fi
    sleep 0.1
    count=$((count+1))
done

# 4. 兜底：如果 App 卡死，强制杀
if pgrep ceanic_app > /dev/null; then
    echo "$(date '+%Y-%m-%d %H:%M:%S'),0,SCRIPT,0,0,0,0,ERROR: App_Stuck_Force_Killed" >>$LOG_FILE
    echo "App stuck, force kill..."
    killall -9 ceanic_app 2>/dev/null
    sleep 1 
        echo "App was force killed. Resetting MPP system to reclaim VB memory..."
    if [ -f /proc/umap/sys ]; then
        echo 0 > /proc/umap/sys 2>/dev/null
        echo "MPP system reset successfully."
    else
        echo "Warning: /proc/umap/sys not found, cannot reset MPP."
    fi
fi
sleep 0.5 

ifconfig wlan0 down 2>/dev/null
pkill -9 -f udhcpd 2>/dev/null
pkill -9 -f hostapd 2>/dev/null
sleep 0.5

# 卸载驱动
rmmod wifi_soc.ko 2>/dev/null 
rmmod plat_soc.ko 2>/dev/null
rmmod mac80211.ko 2>/dev/null
rmmod cfg80211.ko 2>/dev/null
sleep 1

echo "ceanic_app 退出清理结束"
sync

# 清空页缓存
echo 3 > /proc/sys/vm/drop_caches
sleep 2

exit 0
