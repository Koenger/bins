#!/bin/sh
# get_mac.sh

# 定义网卡名称
INTERFACE="wlan0"

# 获取网卡MAC地址（去除冒号，转为小写）
# 移除了转大写的tr命令，保留默认的小写
MAC_ADDR=$(cat /sys/class/net/$INTERFACE/address 2>/dev/null | tr -d ':')

# 检查是否成功获取MAC地址
if [ -z "$MAC_ADDR" ]; then
    echo "错误：无法获取 $INTERFACE 的MAC地址"
    exit 1
fi

# 截取MAC地址后8位（小写）
MAC_LAST8=${MAC_ADDR: -8}

# 定义hostapd配置文件路径
HOSTAPD_CONF="/etc/Wireless/hostapd.conf"
	
# 生成配置文件内容（SSID后8位和密码均为小写MAC）
cat > $HOSTAPD_CONF << EOF
# 极简配置（适配SoftAp内核默认参数，仅保留必要项）
interface=$INTERFACE
driver=nl80211
ssid=DTL_040_$MAC_LAST8
channel=6
hw_mode=g
country_code=CN
ieee80211n=1
# ieee80211ax=1
# ht_capab=[HT40-]
wpa=2
wpa_key_mgmt=WPA-PSK
wpa_passphrase=$MAC_LAST8
wpa_pairwise=CCMP
ctrl_interface=/var/run/hostapd
ctrl_interface_group=0

EOF

