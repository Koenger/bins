#!/bin/sh
# stop_uvc.sh

cleanup_old_resources() {
    local GADGET_PATH="/sys/kernel/config/usb_gadget/camera"

    if [ ! -d "$GADGET_PATH" ]; then
        echo "UVC gadget 未配置，无需清理"
        return 0
    fi

    echo "开始安全逆向清理 UVC gadget..."

    # 1. 解除 UDC 绑定
    if [ -f "$GADGET_PATH/UDC" ] && [ -s "$GADGET_PATH/UDC" ]; then
        echo "解除 UDC 绑定..."
        echo "" > "$GADGET_PATH/UDC"
        sleep 0.5
    fi

    # 2. 删除所有符号链接
    find "$GADGET_PATH" -type l -delete 2>/dev/null

    # 3. 从深层向浅层删除空目录
    find "$GADGET_PATH" -depth -type d -exec rmdir {} \; 2>/dev/null

    if [ -d "$GADGET_PATH" ]; then
        echo "警告: gadget 目录未完全清理！"
    else
        echo "UVC 资源清理完成"
    fi
}

echo "正在停止 UVC 模式..."

# 1. 发送 SIGINT 信号，通知 C 程序优雅退出 (触发 sample_venc_deinit)
killall -2 sample_uvc sample_uvc_v4l2 2>/dev/null

# 2. 智能等待进程退出 (给足 C 程序时间执行 VB 释放，最多等 5 秒)
WAIT_TIME=0
while [ $WAIT_TIME -lt 10 ]; do
    if ! pidof sample_uvc > /dev/null && ! pidof sample_uvc_v4l2 > /dev/null; then
        echo "UVC 进程已优雅退出，VB 应已释放！"
        break
    fi
    sleep 0.5
    WAIT_TIME=$((WAIT_TIME+1))
done

# 3. 兜底：如果 5 秒后还没死，强杀！(慎用，可能导致 VB 漏释放)
if pidof sample_uvc > /dev/null || pidof sample_uvc_v4l2 > /dev/null; then
    echo "警告: UVC 进程退出超时，强制终止！"
    killall -9 sample_uvc sample_uvc_v4l2 2>/dev/null
    sleep 1
fi

# 4. 核心：卸载 UVC 驱动和复合驱动！(强制释放内核态占用的 VB 帧)
echo "卸载 UVC 驱动以释放内核态 VB..."
rmmod uvc 2>/dev/null
rmmod libcomposite 2>/dev/null
sleep 1

# 5. 清理 ConfigFS 节点 (此时驱动已卸载，清理会非常干净)
cleanup_old_resources

# echo "Reclaiming GPIO12 for LED control..."

# {
# # 恢复引脚复用寄存器 (请确保 0x11130000 和 0x04 是你 start.sh 里的配置)
# value=$(timeout 0 bspmm 0x11130000 | grep '0x11130000:' | awk '{print$2}')
# value1=$((value&0xfffff0f0))
# value1=$((value1|0x04))
# bspmm 0x11130000 $value1
# } &

# {
# # 确保 sysfs 节点存在且方向正确
# if [ ! -d /sys/class/gpio/gpio12 ]; then
#     echo 12 > /sys/class/gpio/export
# fi
# echo out > /sys/class/gpio/gpio12/direction
# # 绝对不要在这里写 value，让 key 程序的线程去控制亮灭！
# } &

# wait
# echo "GPIO12 reclaimed successfully."

# 6. 释放系统内存缓存
sync
echo 3 > /proc/sys/vm/drop_caches
sleep 0.5

echo "UVC 模式已停止，内存已回收"
exit 0
