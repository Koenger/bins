#!/bin/sh
# run_wifi.sh

# 0x11130034
{
value=$(timeout 0 bspmm 0x11130034 | grep '0x11130034:' | awk '{print $2}')
value1=$((value&0xfffffff0))
value1=$((value1|0x06))
bspmm 0x11130034 $value1
} &

# 0x11130030
{
value=$(timeout 0 bspmm 0x11130030 | grep '0x11130030:' | awk '{print $2}')
value1=$((value&0xfffffff0))
value1=$((value1|0x02))
bspmm 0x11130030 $value1
} &
wait

{
echo 7 >/sys/class/gpio/export
echo out >/sys/class/gpio/gpio7/direction
echo 0 >/sys/class/gpio/gpio7/value
echo 7 >/sys/class/gpio/unexport
} &

{
echo 6 >/sys/class/gpio/export
echo out >/sys/class/gpio/gpio6/direction
echo 0 >/sys/class/gpio/gpio6/value
echo 6 >/sys/class/gpio/unexport
} &
wait

# 切换USB模式
echo host >/proc/wing-usb/10300000.usb20drd/mode
sleep 0.5

cd /home/wifi_file/ko                                                         
insmod plat_soc.ko                                                         
sleep 0.5
insmod wifi_soc.ko
sleep 0.5

ifconfig wlan0 192.168.10.2 up

rm -f /var/run/hostapd/wlan0
# 【核心优化】将 Wi-Fi 守护进程绑定到 CPU 1 运行 (掩码 2 = CPU 1)
taskset 2 hostapd /etc/Wireless/hostapd.conf &

# 【核心优化】将 DHCP 守护进程绑定到 CPU 1 运行
taskset 2 busybox udhcpd -S /etc/Wireless/udhcpd.conf &
sleep 0.5

MAX_RETRY=30  # 最多等 30 次，防止死循环

for i in $(seq 1 $MAX_RETRY)
do
    # 检查 wlan0 是否已经启动并拥有 IP
    if ifconfig wlan0 | grep -q "192.168.10.2"; then
        echo "WLAN0 is UP and IP is set!"
        break  # 检测到了，跳出循环，继续往下走
    fi
    
    if [ "$i" -eq "$MAX_RETRY" ]; then
        echo "ERROR: WLAN0 failed to come up! Aborting."
        echo "$(date '+%Y-%m-%d %H:%M:%S'),0,SCRIPT,0,0,0,0,ERROR: WiFi_WLAN0_Timeout" >> $LOG_FILE
        sync
        exit 1
    fi
    
    sleep 0.1  # 每次间隔 0.1 秒
done


cd /home
# 【核心优化】将 MPP 视频应用绑定到 CPU 0 运行 (掩码 1 = CPU 0)
# 让视频业务独占一个核心，不受 Wi-Fi 烦扰！
taskset 1 ./ceanic_app &


sleep 0.5
exit 0
