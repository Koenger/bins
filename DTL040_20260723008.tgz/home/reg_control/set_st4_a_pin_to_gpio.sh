#!/bin/sh

value=$(timeout 0 bspmm 0x11130038 | grep '0x11130038:' | awk '{print $2}')
value1=$((value&0xfffff0f0))
bspmm 0x11130038 $value1
sleep 0

exit 0

