#!/bin/sh
cd /home/reg_control
./set_ir_b_pin_to_gpio.sh
sleep 0
echo 61 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio61/direction
echo 1 > /sys/class/gpio/gpio61/value
sleep 1
echo 0 > /sys/class/gpio/gpio61/value
echo 61 > /sys/class/gpio/unexport
