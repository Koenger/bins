value=$(timeout 0 bspmm 0x1113004c | grep '0x1113004c:' | awk '{print $2}')
value1=$((value&0xfffffff0))
bspmm 0x1113004c $value1  
sleep 0                                           
echo 62 > /sys/class/gpio/export          
echo in > /sys/class/gpio/gpio62/direction
