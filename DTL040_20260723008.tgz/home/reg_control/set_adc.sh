#!/bin/sh

value=$(timeout 0 bspmm 0x11130000 | grep '0x11130000:' | awk '{print $2}')
value1=$((value&0xfffff0f0))
bspmm 0x11130000 $value1

exit 0

