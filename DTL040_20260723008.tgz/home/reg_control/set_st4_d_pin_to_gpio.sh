#!/bin/sh

value=$(timeout 0 bspmm 0x11130044 | grep '0x11130044:' | awk '{print $2}')
value1=$((value&0xfffff0f0))
value1=$((value1|0x02))
bspmm 0x11130044 $value1
sleep 0

exit 0

