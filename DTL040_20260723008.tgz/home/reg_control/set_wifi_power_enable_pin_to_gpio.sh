#!/bin/sh

value=$(timeout 0 bspmm 0x11130030 | grep '0x11130030:' | awk '{print $2}')  
value1=$((value&0xfffffff0))
value1=$((value1|0x02))
bspmm 0x11130030 $value1

exit 0


