#!/bin/sh

value=$(timeout 0 bspmm 0x11130048 | grep '0x11130048:' | awk '{print $2}')
value1=$((value&0xfffffff0))
bspmm 0x11130048 $value1  
sleep 0

exit 0
