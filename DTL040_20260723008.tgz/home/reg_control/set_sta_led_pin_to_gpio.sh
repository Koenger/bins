#!/bin/sh

value=$(timeout 0 bspmm 0x11130004 | grep '0x11130004:' | awk '{print $2}')  
value1=$((value&0xfffffff0))
bspmm 0x11130004 $value1

#exit 0

