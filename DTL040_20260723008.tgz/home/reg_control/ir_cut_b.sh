#!/bin/sh
cd /home/reg_control
./set_ir_a_pin_to_gpio.sh
sleep 0
echo 60 > /sys/class/gpio/export
echo out > /sys/class/gpio/gpio60/direction
echo 1 > /sys/class/gpio/gpio60/value
sleep 1
echo 0 > /sys/class/gpio/gpio60/value
echo 60 > /sys/class/gpio/unexport
