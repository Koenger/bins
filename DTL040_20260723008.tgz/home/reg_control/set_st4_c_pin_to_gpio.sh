#!/bin/sh

value=$(timeout 0 bspmm 0x11130040 | grep '0x11130040:' | awk '{print $2}')
value1=$((value&0xfffff0f0))
bspmm 0x11130040 $value1
sleep 0

exit 0

