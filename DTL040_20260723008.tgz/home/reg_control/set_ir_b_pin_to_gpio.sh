#!/bin/sh

value=$(timeout 0 bspmm 0x11130054 | grep '0x11130054:' | awk '{print $2}')  
value1=$((value&0xfffffff0))
value1=$((value1|0x05))
bspmm 0x11130054 $value1

exit 0


