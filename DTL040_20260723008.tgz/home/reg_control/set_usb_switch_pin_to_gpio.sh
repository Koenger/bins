#!/bin/sh

value=$(timeout 0 bspmm 0x11130034 | grep '0x11130034:' | awk '{print $2}')  
value1=$((value&0xfffffff0))
value1=$((value1|0x06))
bspmm 0x11130034 $value1

exit 0


