#!/bin/sh

value=$(timeout 0 bspmm 0x17940090 | grep '0x17940090:' | awk '{print $2}')  
value1=$((value&0xfffffff0))
bspmm 0x17940090 $value1

exit 0

