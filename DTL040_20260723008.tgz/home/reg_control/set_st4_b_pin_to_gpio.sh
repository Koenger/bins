#!/bin/sh

value=$(timeout 0 bspmm 0x1113003C | grep '0x1113003C:' | awk '{print $2}')
value1=$((value&0xfffff0f0))
bspmm 0x1113003C $value1
sleep 0

exit 0

