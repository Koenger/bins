#!/bin/sh

value=$(timeout 0 bspmm 0x17940094 | grep '0x17940094:' | awk '{print $2}')
#echo "value:$value"  
value1=$((value&0xfffffff0))
bspmm 0x17940094 $value1
#bspmm 0x17940094

exit 0


