
# start.sh
# 0x17940094
{
value=$(timeout 0 bspmm 0x17940094 | grep '0x17940094:' | awk '{print $2}')
value1=$((value&0xfffffff0))
bspmm 0x17940094 $value1
} &

# 0x11130004
{
value=$(timeout 0 bspmm 0x11130004 | grep '0x11130004:' | awk '{print $2}')
value1=$((value&0xfffffff0))
bspmm 0x11130004 $value1
} &

# 0x11130034
{
value=$(timeout 0 bspmm 0x11130034 | grep '0x11130034:' | awk '{print $2}')
value1=$((value&0xfffffff0))
value1=$((value1|0x06))
bspmm 0x11130034 $value1
} &

# 0x11130030
{
value=$(timeout 0 bspmm 0x11130030 | grep '0x11130030:' | awk '{print $2}')
value1=$((value&0xfffffff0))
value1=$((value1|0x02))
bspmm 0x11130030 $value1
} &

# 0x11130048
{
value=$(timeout 0 bspmm 0x11130048 | grep '0x11130048:' | awk '{print $2}')
value1=$((value&0xfffffff0))
bspmm 0x11130048 $value1
} &

# 0x1113004c
{
value=$(timeout 0 bspmm 0x1113004c | grep '0x1113004c:' | awk '{print $2}')
value1=$((value&0xfffff0f0))
bspmm 0x1113004c $value1
} &

# 0x11130000
{
value=$(timeout 0 bspmm 0x11130000 | grep '0x11130000:' | awk '{print $2}')
value1=$((value&0xfffff0f0))
value1=$((value1|0x04))
bspmm 0x11130000 $value1
} &

# 等待所有后台bspmm执行完成
wait

# ===================== 合并GPIO集中操作 =====================
# GPIO56
echo 56 >/sys/class/gpio/export
echo out >/sys/class/gpio/gpio56/direction
echo 1 >/sys/class/gpio/gpio56/value
echo 56 >/sys/class/gpio/unexport

# GPIO57
echo 57 >/sys/class/gpio/export
echo out >/sys/class/gpio/gpio57/direction
echo 1 >/sys/class/gpio/gpio57/value
echo 57 >/sys/class/gpio/unexport

# GPIO12 led
# echo 12 >/sys/class/gpio/export
# echo out >/sys/class/gpio/gpio12/direction
# echo 0 >/sys/class/gpio/gpio12/value # 0
# echo 12 >/sys/class/gpio/unexport

# GPIO7
echo 7 >/sys/class/gpio/export
echo out >/sys/class/gpio/gpio7/direction
echo 0 >/sys/class/gpio/gpio7/value
echo 7 >/sys/class/gpio/unexport

# GPIO6
echo 6 >/sys/class/gpio/export
echo out >/sys/class/gpio/gpio6/direction
echo 0 >/sys/class/gpio/gpio6/value
echo 6 >/sys/class/gpio/unexport

# GPIO9
echo 9 > /sys/class/gpio/export
echo in > /sys/class/gpio/gpio9/direction

# GPIO62
echo 62 > /sys/class/gpio/export
echo in > /sys/class/gpio/gpio62/direction
