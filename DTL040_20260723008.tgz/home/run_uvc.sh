#!/bin/sh
# run_uvc.sh

cd /home/reg_control

echo 7 >/sys/class/gpio/export
echo out >/sys/class/gpio/gpio7/direction
echo 1 >/sys/class/gpio/gpio7/value
echo 7 >/sys/class/gpio/unexport

echo 6 >/sys/class/gpio/export
echo out >/sys/class/gpio/gpio6/direction
echo 1 >/sys/class/gpio/gpio6/value
echo 6 >/sys/class/gpio/unexport

# 切换USB为Device模式
echo device >/proc/wing-usb/10300000.usb20drd/mode

export VID="0x1D6B"
export PID="0x0004"
export MANUFACTURER="Vendor"
export PRODUCT="Camera"
export SERIALNUMBER="123456789012"
export BCDUVC="0x0110"

export UVC_DEVICE_CNT=1

export CamControl1=0xFF
export CamControl2=0x7F
export CamControl3=0x3E
export ProcControl1=0xFF
export ProcControl2=0xFF
export ProcControl3=0x07
export EcdControl1=0xff
export EcdControl2=0xff
export EcdControl3=0x0f
export EcdRtControl1=0xf
export EcdRtControl2=0xff
export EcdRtControl3=0x0f
export ExtControl1=0xff
export ExtControl2=0xff

export YUYV="360p 720p 1080p 1440p"
export NV21="360p 720p 1080p 1440p"
export NV12="360p 720p 1080p 1440p"
export MJPEG="360p 720p 1080p 1440p"
export H264="360p 720p 1080p 1440p"
export H265="360p 720p 1080p 1440p"

if [ "$StillCaptureMethod" == 2 -o "$StillCaptureMethod" == 3 -o "${PerfMode}" == "v4l2" ] ; then
 export YUYV="360p 720p 1080p"
 export NV21="360p 720p 1080p"
 export NV12="360p 720p 1080p"
fi

if [ ${UVC_DEVICE_CNT} != 1 ] ; then
 export YUYV="360p"
 export NV21="360p"
 export NV12="360p"
 export MJPEG="360p 720p 1080p"
 export H264="360p 720p 1080p"
 export H265="360p 720p 1080p"
fi

cd /home/uvc_file

# ==========================================
# 新增：重新加载 UVC 和复用驱动！
# 因为 stop_uvc.sh 卸载了它们，必须装回来
# ==========================================
if ! lsmod | grep -q libcomposite; then
    insmod /home/ko/libcomposite.ko  # 请根据你的实际 ko 路径修改！
fi
if ! lsmod | grep -q "^uvc "; then
    insmod /home/ko/uvc.ko           # 请根据你的实际 ko 路径修改！
fi
sleep 0.5

./ConfigUVC_2.0.sh

cd /home

# ==========================================
# 优化：移除危险的强制清理逻辑
# 既然改了 C 代码优雅退出，就不需要这个了
# ==========================================
echo "Checking MPP VB status before starting UVC..."
if [ -f /proc/umap/vb ]; then
    VB_FREE=$(cat /proc/umap/vb | grep "Common pool" -A 4 | grep "Free" | awk '{print$2}')
    echo "Current VB Free blocks: $VB_FREE"
    # 如果 Free 块极少，说明上一次退出仍有残留，这是排查 C 代码 deinit 是否生效的最好依据
    if [ "$VB_FREE" -lt 10 ]; then
        echo "WARNING: VB pool is not fully free! The deinit in C code may not be working."
    fi
fi

./sample_uvc ${UVC_DEVICE_CNT} 0 &

sleep 0.5
exit 0
